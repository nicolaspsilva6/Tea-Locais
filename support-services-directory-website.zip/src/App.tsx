import { useRef, useState } from "react";

type Place = {
  name: string;
  summary: string;
  address?: string;
  mapsQuery: string;
  accent: string;
};

type Section = {
  id: string;
  label: string;
  title: string;
  intro: string;
  accent: string;
  places: Place[];
};

const sections: Section[] = [
  {
    id: "sus",
    label: "SUS",
    title: "Porta de entrada e continuidade do cuidado",
    intro:
      "Comece pela UBS para agendar, receber encaminhamentos e conectar a pessoa com a rede multidisciplinar. Depois, o fluxo pode seguir para reabilitação, saúde mental e apoio estadual especializado.",
    accent: "from-cyan-300 to-sky-500",
    places: [
      {
        name: "UBS",
        summary:
          "Agendamento com pediatra ou clínico geral para encaminhamento ao especialista e equipe multidisciplinar: neuropediatra, psiquiatra, psicólogo, fonoaudiólogo e assistente social.",
        mapsQuery: "UBS em Sao Paulo atendimento TEA",
        accent: "border-cyan-300/40 text-cyan-200",
      },
      {
        name: "CER - Centro Especializado em Reabilitação",
        summary:
          "Terapias para o desenvolvimento de habilidades motoras, cognitivas e de comunicação.",
        mapsQuery: "Centro Especializado em Reabilitacao CER Sao Paulo TEA",
        accent: "border-sky-300/40 text-sky-200",
      },
      {
        name: "CAPS ou CAPSi",
        summary:
          "Suporte psicossocial, acolhimento em momentos de crise comportamental e fortalecimento da rede de apoio à família.",
        mapsQuery: "CAPSi Sao Paulo apoio TEA",
        accent: "border-indigo-300/40 text-indigo-200",
      },
      {
        name: "Centro TEA Paulista",
        summary:
          "Equipamento público estadual focado no suporte e inclusão de pessoas autistas.",
        address: "Rua Galileo Emendabili, 99 - Jardim Humaitá",
        mapsQuery: "Rua Galileo Emendabili, 99 - Jardim Humaita Sao Paulo",
        accent: "border-violet-300/40 text-violet-200",
      },
    ],
  },
  {
    id: "ongs",
    label: "Associações e ONGs",
    title: "Apoio estruturado, convivência e orientação para a família",
    intro:
      "Esses espaços fortalecem a rotina, oferecem suporte especializado e ajudam a construir um caminho mais humano entre diagnóstico, cuidado e inclusão.",
    accent: "from-emerald-300 to-teal-500",
    places: [
      {
        name: "AMA - Associação de Amigos do Autista",
        summary:
          "Oferece suporte estruturado, diagnóstico e atendimento educacional para crianças, jovens e adultos no espectro.",
        address: "Rua do Lavapés, 1123 - Cambuci",
        mapsQuery: "Rua do Lavapes, 1123 - Cambuci Sao Paulo",
        accent: "border-emerald-300/40 text-emerald-200",
      },
      {
        name: "Beneficência Nipo-Brasileira de São Paulo - Projeto PIPA",
        summary:
          "Focada na integração e no desenvolvimento de pessoas com TEA, com tratamento multidisciplinar e foco em atividades de vida diária para crianças e jovens.",
        address: "Av. José Maria Fernandes, 618 - Parque Novo Mundo",
        mapsQuery: "Av. Jose Maria Fernandes, 618 - Parque Novo Mundo Sao Paulo",
        accent: "border-teal-300/40 text-teal-200",
      },
    ],
  },
  {
    id: "clinicas",
    label: "Clínicas Particulares Especializadas",
    title: "Atendimento integrado para acompanhar diferentes fases da vida",
    intro:
      "Para quem busca suporte privado, estas clínicas oferecem propostas terapêuticas e educacionais com foco em desenvolvimento, autonomia e neurodivergência.",
    accent: "from-amber-300 to-orange-500",
    places: [
      {
        name: "Centro Terapêutico Educacional Lumi",
        summary:
          "Voltado tanto para o aspecto clínico quanto educacional, com foco no desenvolvimento das habilidades dos pacientes.",
        address: "Rua Campos do Jordão, 162 - Caxingui",
        mapsQuery: "Rua Campos do Jordao, 162 - Caxingui Sao Paulo",
        accent: "border-amber-300/40 text-amber-200",
      },
      {
        name: "Clínica Formare - Atendimento Comportamental Integrado",
        summary:
          "Trabalha com a neurodivergência e oferece suporte para todos os níveis de necessidade, da infância à vida adulta.",
        address: "Av. Washington Luís, 7059 - Campo Belo",
        mapsQuery: "Av. Washington Luis, 7059 - Campo Belo Sao Paulo",
        accent: "border-orange-300/40 text-orange-200",
      },
    ],
  },
];

function buildMapsUrl(query: string) {
  return `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(query)}`;
}

function NetworkCanvas() {
  return (
    <div className="relative min-h-[32rem] overflow-hidden rounded-[2rem] border border-white/10 bg-[linear-gradient(180deg,rgba(15,23,42,0.88),rgba(2,6,23,0.98))] shadow-[0_30px_80px_-40px_rgba(56,189,248,0.45)]">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_20%,rgba(34,211,238,0.18),transparent_30%),radial-gradient(circle_at_75%_25%,rgba(168,85,247,0.14),transparent_30%),radial-gradient(circle_at_50%_80%,rgba(16,185,129,0.12),transparent_25%)]" />
      <svg
        className="absolute inset-0 h-full w-full opacity-95"
        viewBox="0 0 680 620"
        fill="none"
        aria-hidden="true"
      >
        <defs>
          <linearGradient id="routeA" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="rgba(34,211,238,0.9)" />
            <stop offset="100%" stopColor="rgba(129,140,248,0.8)" />
          </linearGradient>
          <linearGradient id="routeB" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0%" stopColor="rgba(16,185,129,0.9)" />
            <stop offset="100%" stopColor="rgba(45,212,191,0.6)" />
          </linearGradient>
          <filter id="glow">
            <feGaussianBlur stdDeviation="5" result="blur" />
            <feMerge>
              <feMergeNode in="blur" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
        </defs>

        <path
          d="M88 476 C196 387, 235 292, 330 300 S514 255, 612 144"
          stroke="url(#routeA)"
          strokeWidth="3"
          strokeLinecap="round"
          strokeDasharray="10 16"
        />
        <path
          d="M108 168 C181 132, 257 140, 307 191 S412 287, 502 338 S575 425, 598 514"
          stroke="url(#routeB)"
          strokeWidth="2.5"
          strokeLinecap="round"
          strokeDasharray="8 14"
          opacity="0.9"
        />
        <path
          d="M142 553 C167 490, 182 448, 225 406 S308 339, 381 337 S510 361, 582 321"
          stroke="rgba(148,163,184,0.34)"
          strokeWidth="1.5"
          strokeLinecap="round"
          strokeDasharray="1 13"
        />
        <path
          d="M84 98 C188 84, 244 104, 303 160 S414 254, 491 223 S575 182, 616 218"
          stroke="rgba(148,163,184,0.26)"
          strokeWidth="1.5"
          strokeLinecap="round"
          strokeDasharray="1 11"
        />

        <circle cx="92" cy="476" r="12" fill="rgba(34,211,238,0.18)" stroke="rgba(34,211,238,0.9)" strokeWidth="2" filter="url(#glow)" />
        <circle cx="330" cy="300" r="14" fill="rgba(129,140,248,0.2)" stroke="rgba(129,140,248,0.95)" strokeWidth="2" filter="url(#glow)" />
        <circle cx="502" cy="338" r="12" fill="rgba(16,185,129,0.18)" stroke="rgba(16,185,129,0.95)" strokeWidth="2" filter="url(#glow)" />
        <circle cx="612" cy="144" r="11" fill="rgba(251,191,36,0.2)" stroke="rgba(251,191,36,0.95)" strokeWidth="2" filter="url(#glow)" />
        <circle cx="225" cy="406" r="8" fill="rgba(226,232,240,0.8)" opacity="0.75" />
        <circle cx="381" cy="337" r="8" fill="rgba(226,232,240,0.8)" opacity="0.65" />
        <circle cx="598" cy="514" r="8" fill="rgba(226,232,240,0.8)" opacity="0.55" />

        <path
          d="M220 230 L303 160 L418 205 L491 223"
          stroke="rgba(255,255,255,0.08)"
          strokeWidth="1"
          strokeLinecap="round"
        />
        <path
          d="M176 518 L225 406 L304 444 L381 337 L455 390 L598 514"
          stroke="rgba(255,255,255,0.08)"
          strokeWidth="1"
          strokeLinecap="round"
        />
      </svg>

      <div className="absolute left-10 top-10 h-28 w-28 rounded-full border border-cyan-400/20 bg-cyan-300/10 blur-2xl float-slow" />
      <div className="absolute right-8 top-20 h-36 w-36 rounded-full border border-violet-400/20 bg-violet-500/10 blur-3xl float-medium" />
      <div className="absolute bottom-10 left-1/2 h-32 w-32 -translate-x-1/2 rounded-full border border-emerald-400/20 bg-emerald-500/10 blur-3xl pulse-slow" />

      <div className="absolute left-[12%] top-[22%] h-3 w-3 rounded-full bg-cyan-300 shadow-[0_0_0_18px_rgba(34,211,238,0.08)] float-medium" />
      <div className="absolute left-[45%] top-[41%] h-4 w-4 rounded-full bg-violet-300 shadow-[0_0_0_22px_rgba(129,140,248,0.08)] float-slow" />
      <div className="absolute left-[72%] top-[53%] h-3.5 w-3.5 rounded-full bg-emerald-300 shadow-[0_0_0_20px_rgba(16,185,129,0.08)] float-medium" />
      <div className="absolute left-[84%] top-[18%] h-3.5 w-3.5 rounded-full bg-amber-300 shadow-[0_0_0_18px_rgba(251,191,36,0.08)] float-slow" />

      <div className="absolute inset-x-0 bottom-0 h-28 bg-gradient-to-t from-slate-950 to-transparent" />
    </div>
  );
}

function PlaceRow({ place, index, sectionLabel, onCopy, copiedId }: { place: Place; index: number; sectionLabel: string; onCopy: (id: string, text: string) => void; copiedId: string | null; }) {
  const addressText = place.address ?? "Endereço não informado neste recorte";
  const copyLabel = copiedId === `${sectionLabel}-${index}` ? "Copiado" : "Copiar";

  return (
    <article className="grid gap-4 border-t border-white/10 py-6 transition-colors duration-300 hover:bg-white/[0.02] md:grid-cols-[150px_minmax(0,1fr)_260px] md:gap-6 md:px-2">
      <div className="space-y-2">
        <div className={`inline-flex items-center gap-2 border-l-2 pl-3 text-xs uppercase tracking-[0.3em] ${place.accent}`}>
          <span className="h-1.5 w-1.5 rounded-full bg-current" />
          {sectionLabel}
        </div>
        <div className="text-sm text-slate-400">#{String(index + 1).padStart(2, "0")}</div>
      </div>

      <div className="space-y-3">
        <h3 className="text-xl font-semibold text-slate-50">{place.name}</h3>
        <p className="max-w-3xl text-sm leading-7 text-slate-300">{place.summary}</p>
      </div>

      <div className="space-y-3 md:justify-self-end md:text-right">
        <div className="text-sm leading-6 text-slate-300">{addressText}</div>
        <div className="flex flex-wrap gap-2 md:justify-end">
          <a
            href={buildMapsUrl(place.mapsQuery)}
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center justify-center rounded-full border border-white/15 bg-white/5 px-4 py-2 text-sm font-medium text-slate-100 transition hover:border-white/25 hover:bg-white/10"
          >
            Abrir no Maps
          </a>
          {place.address ? (
            <button
              type="button"
              onClick={() => onCopy(`${sectionLabel}-${index}`, place.address as string)}
              className="inline-flex items-center justify-center rounded-full border border-cyan-300/20 bg-cyan-300/10 px-4 py-2 text-sm font-medium text-cyan-100 transition hover:border-cyan-300/35 hover:bg-cyan-300/15"
            >
              {copyLabel}
            </button>
          ) : null}
        </div>
      </div>
    </article>
  );
}

function SectionBlock({ section, onCopy, copiedId }: { section: Section; onCopy: (id: string, text: string) => void; copiedId: string | null; }) {
  return (
    <section id={section.id} className="scroll-mt-24 border-t border-white/10 py-14 md:py-16">
      <div className="grid gap-4 lg:grid-cols-[280px_minmax(0,1fr)] lg:items-end">
        <div>
          <p className={`text-xs uppercase tracking-[0.42em] bg-gradient-to-r ${section.accent} bg-clip-text text-transparent`}>
            {section.label}
          </p>
          <h2 className="mt-4 text-3xl font-semibold tracking-tight text-white md:text-4xl">
            {section.title}
          </h2>
        </div>
        <p className="max-w-3xl text-sm leading-7 text-slate-300 md:text-base">{section.intro}</p>
      </div>

      <div className="mt-8">
        {section.places.map((place, index) => (
          <PlaceRow
            key={place.name}
            place={place}
            index={index}
            sectionLabel={section.label}
            onCopy={onCopy}
            copiedId={copiedId}
          />
        ))}
      </div>
    </section>
  );
}

export default function App() {
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const timerRef = useRef<number | null>(null);

  const handleCopy = async (id: string, text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedId(id);

      if (timerRef.current) {
        window.clearTimeout(timerRef.current);
      }

      timerRef.current = window.setTimeout(() => {
        setCopiedId(null);
      }, 1800);
    } catch {
      setCopiedId(null);
    }
  };

  return (
    <main className="relative isolate overflow-hidden bg-slate-950 text-slate-100">
      <div className="absolute inset-x-0 top-0 -z-10 h-[46rem] bg-[radial-gradient(circle_at_top_left,rgba(56,189,248,0.16),transparent_36%),radial-gradient(circle_at_top_right,rgba(168,85,247,0.14),transparent_30%),radial-gradient(circle_at_50%_70%,rgba(16,185,129,0.1),transparent_28%)]" />
      <div className="absolute inset-x-0 top-0 -z-10 h-[46rem] bg-[linear-gradient(180deg,rgba(2,6,23,0.35),rgba(2,6,23,0.96))]" />

      <div className="mx-auto flex min-h-screen w-full max-w-7xl flex-col px-6 pb-16 pt-6 lg:px-8 lg:pb-24">
        <header className="flex items-center justify-between gap-4 border-b border-white/10 pb-5">
          <a href="#topo" className="group inline-flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-2xl border border-white/10 bg-white/5 shadow-[0_0_0_1px_rgba(255,255,255,0.02)] transition group-hover:border-cyan-300/30 group-hover:bg-cyan-300/10">
              <svg className="h-5 w-5 text-cyan-200" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                <path d="M12 21s6-5.2 6-11a6 6 0 0 0-12 0c0 5.8 6 11 6 11Z" />
                <circle cx="12" cy="10" r="2.2" />
              </svg>
            </div>
            <div>
              <div className="text-xs uppercase tracking-[0.32em] text-slate-400">Mapa de apoio</div>
              <div className="text-sm font-medium text-slate-100">TEA</div>
            </div>
          </a>

          <nav className="hidden items-center gap-6 text-sm text-slate-300 md:flex">
            <a className="transition hover:text-white" href="#sus">SUS</a>
            <a className="transition hover:text-white" href="#ongs">Associações</a>
            <a className="transition hover:text-white" href="#clinicas">Clínicas</a>
          </nav>
        </header>

        <section id="topo" className="grid flex-1 items-center gap-10 py-10 lg:grid-cols-[minmax(0,0.9fr)_minmax(0,1.1fr)] lg:gap-12 lg:py-14">
          <div className="space-y-8">
            <div className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-4 py-2 text-xs uppercase tracking-[0.3em] text-cyan-100/90 backdrop-blur">
              Rede organizada para acolhimento e orientação
            </div>

            <div className="space-y-5">
              <h1 className="max-w-3xl text-5xl font-semibold tracking-tight text-white sm:text-6xl lg:text-7xl">
                Mapa de apoio TEA em um só lugar.
              </h1>
              <p className="max-w-2xl text-base leading-8 text-slate-300 sm:text-lg">
                Um site bonito e direto para apresentar locais de apoio do SUS, associações e clínicas especializadas. A ideia aqui é facilitar a leitura, valorizar cada rede de cuidado e ajudar famílias a encontrar o próximo passo com mais clareza.
              </p>
            </div>

            <div className="flex flex-wrap gap-3">
              <a
                href="#sus"
                className="inline-flex items-center justify-center rounded-full bg-white px-5 py-3 text-sm font-semibold text-slate-950 transition hover:-translate-y-0.5 hover:bg-cyan-100"
              >
                Explorar locais
              </a>
              <a
                href="#ongs"
                className="inline-flex items-center justify-center rounded-full border border-white/15 bg-white/5 px-5 py-3 text-sm font-medium text-slate-100 transition hover:-translate-y-0.5 hover:border-white/25 hover:bg-white/10"
              >
                Ver redes de apoio
              </a>
            </div>
          </div>

          <NetworkCanvas />
        </section>

        <section className="border-t border-white/10 py-10 md:py-12">
          <div className="grid gap-4 lg:grid-cols-[280px_minmax(0,1fr)] lg:items-end">
            <div>
              <p className="text-xs uppercase tracking-[0.38em] text-slate-500">Locais de apoio</p>
              <h2 className="mt-4 text-2xl font-semibold tracking-tight text-white md:text-3xl">
                Cada caminho tem uma função diferente.
              </h2>
            </div>
            <p className="max-w-3xl text-sm leading-7 text-slate-300 md:text-base">
              A organização abaixo separa os espaços por tipo de suporte para ficar mais fácil entender quando procurar acolhimento, reabilitação, integração social ou atendimento especializado.
            </p>
          </div>
        </section>

        <div>
          {sections.map((section) => (
            <SectionBlock key={section.id} section={section} onCopy={handleCopy} copiedId={copiedId} />
          ))}
        </div>

        <footer className="border-t border-white/10 pt-8 text-sm leading-7 text-slate-400">
          As informações acima foram organizadas a partir do conteúdo fornecido. Antes de ir, vale confirmar horários, disponibilidade e exigências de encaminhamento diretamente com cada serviço.
        </footer>
      </div>

      {copiedId ? (
        <div className="fixed bottom-6 left-1/2 z-50 -translate-x-1/2 rounded-full border border-cyan-300/20 bg-slate-900/90 px-4 py-2 text-sm text-cyan-100 shadow-2xl shadow-cyan-950/30 backdrop-blur">
          Endereço copiado para a área de transferência.
        </div>
      ) : null}
    </main>
  );
}
